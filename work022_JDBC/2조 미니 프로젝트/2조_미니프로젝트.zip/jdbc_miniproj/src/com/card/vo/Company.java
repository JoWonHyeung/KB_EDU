package com.card.vo;

public class Company {

}
